package com.example.SpringBoot1backendpart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot1BackendPartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot1BackendPartApplication.class, args);
	}

}
