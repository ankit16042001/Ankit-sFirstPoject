package com.patients.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patient")
public class Patient {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long id;
	 
	 private String name;
	 
	 private String gender;
	 private int age;
	 private String blood_group;
	 private long phone_number;
	 private String issue;
	 
	public Patient(long id, String name, String gender, int age, String blood_group, long phone_number,
			String issue) {

		this.id = id;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.blood_group = blood_group;
		this.phone_number = phone_number;
		this.issue = issue;
	}

	public Patient() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getGender() {
		return gender;
	}

	public int getAge() {
		return age;
	}

	public String getBlood_group() {
		return blood_group;
	}

	public long getPhone_number() {
		return phone_number;
	}

	public String getIssue() {
		return issue;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setBlood_group(String blood_group) {
		this.blood_group = blood_group;
	}

	public void setPhone_number(long phone_number) {
		this.phone_number = phone_number;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}
	
	 
}
