package com.example.SpringBoot1backendpart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot1BackendPartApplicationTests {

	@Test
	void contextLoads() {
	}

}
