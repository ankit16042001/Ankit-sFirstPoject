package com.example.Hospital_Reception_System.Service;

import com.example.Hospital_Reception_System.DTO.DoctorDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.response.LoginResponse_Doctor;

public interface DoctorService {
    String addDoctor(DoctorDTO DoctorDTO);
    LoginResponse_Doctor loginResponse_Doctor(LoginDTO loginDTO);

}
