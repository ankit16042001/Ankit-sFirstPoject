package com.example.Hospital_Reception_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.Entity.Bill;
import com.example.Hospital_Reception_System.Repo.BillRepository;

@RestController
@CrossOrigin
@RequestMapping("api/v1")
public class BillController {
	@Autowired
	 private BillRepository billRepository;
	
    @GetMapping("/search_bill")
    public List<Bill> searchItems(@RequestParam String patientName) {
        return billRepository.findBypatientNameContaining(patientName);
    }
	
	@GetMapping("/bills")
	 public Page<Bill> getBills(Pageable pageable) {
	  return billRepository.findAll(pageable);
	 }
	 
	        //For Deleteing a record
	 @DeleteMapping("/bills/{bill_No}")
	 public ResponseEntity<Bill> deleteBill(@PathVariable("bill_No") long bill_No){
	  try {
	   System.out.println("inside");
	   billRepository.deleteById(bill_No);
	  return new ResponseEntity<Bill>(HttpStatus.OK);
	  }
	  catch (Exception e) {
	   // TODO: handle exception
	   return new ResponseEntity<Bill>(HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	 }
	 
	 
//Add a Bill
@PostMapping("/bills")
public ResponseEntity<Bill> addBills(@RequestBody Bill bill) {
return new ResponseEntity<Bill>(billRepository.save(bill), HttpStatus.OK);
}


//Get Bills By Id
@GetMapping("/bill/bills/{bill_No}")
public ResponseEntity<Bill> getBillById(@PathVariable("bill_No") long bill_No) {
System.out.println("here");
return new ResponseEntity<Bill>(billRepository.findById(bill_No).get(),HttpStatus.OK);

}
@PutMapping("/bill/bills/{bill_No}")
public ResponseEntity<Bill> updateBill(@PathVariable("bill_No") long bill_No, @RequestBody Bill bill){
	Bill b = billRepository.findById(bill_No).get();
 if(b.getBill_No()!=0) {
	b.setPatientName(bill.getPatientName());
   b.setDoctor_Name(bill.getDoctor_Name());
   b.setAmount(bill.getAmount());
   b.setInsurance(bill.getInsurance());
   b.setReport_Status(bill.getReport_Status());
   
 }
return new ResponseEntity<Bill>(billRepository.save(b),HttpStatus.OK);
}
}
