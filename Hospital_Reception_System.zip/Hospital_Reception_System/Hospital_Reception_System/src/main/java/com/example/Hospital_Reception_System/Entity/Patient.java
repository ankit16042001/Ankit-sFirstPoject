package com.example.Hospital_Reception_System.Entity;

import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patient")
public class Patient {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long patient_id;
	 
	 private String patientName;
	 private String gender;
	 private long age;
	 private String bloodGroup;
	 private long phoneNumber;
	 private String issue;
	 private String status;
	 
	public Patient(long patient_id, String patientName, String gender, long age, String bloodGroup, long phoneNumber,
			String issue, String status) {

		this.patient_id = patient_id;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.bloodGroup = bloodGroup;
		this.phoneNumber = phoneNumber;
		this.issue = issue;
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Patient() {
	}

	public long getPatient_id() {
		return patient_id;
	}

	public void setPatient_id(long patient_id) {
		this.patient_id = patient_id;
	}

	public String getPatientName() {
		return patientName;
	}

	public String getGender() {
		return gender;
	}

	public long getAge() {
		return age;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public String getIssue() {
		return issue;
	}



	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}
	
	 
}
