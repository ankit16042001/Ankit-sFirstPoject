package com.example.Hospital_Reception_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.Entity.Patient;
import com.example.Hospital_Reception_System.Repo.PatientRepository;

@RestController
@CrossOrigin
@RequestMapping("api/v1")
public class PatientController {
	@Autowired
	 private PatientRepository patientRepository;

    @GetMapping("/search")
    public List<Patient> searchItems(@RequestParam String patientName) {
        return patientRepository.findBypatientNameContaining(patientName);
    }
	 @GetMapping("/patients")
	 public Page<Patient> getAllPatients(Pageable pageable) {
	  return patientRepository.findAll(pageable);
	 }
	 @DeleteMapping("/patients/{patient_id}")
	 public ResponseEntity<Patient> deletePatient(@PathVariable("patient_id") long patient_id){
	  try {
	   System.out.println("inside");
	  patientRepository.deleteById(patient_id);
	  return new ResponseEntity<Patient>(HttpStatus.OK);
	  }
	  catch (Exception e) {
	   // TODO: handle exception
	   return new ResponseEntity<Patient>(HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	 }
	 
	 
//Add a Patient
@PostMapping("/patients")
public ResponseEntity<Patient> addPatients(@RequestBody Patient patient) {
return new ResponseEntity<Patient>(patientRepository.save(patient), HttpStatus.OK);
}


//Get Books By Id
@GetMapping("/patient/patients/{patient_id}")
public ResponseEntity<Patient> getPatientById(@PathVariable("patient_id") long patient_id) {
System.out.println("here");
return new ResponseEntity<Patient>(patientRepository.findById(patient_id).get(),HttpStatus.OK);

}
@PutMapping("/patient/patients/{patient_id}")
public ResponseEntity<Patient> updatePatient(@PathVariable("patient_id") long patient_id, @RequestBody Patient patient){
Patient p = patientRepository.findById(patient_id).get();
  if(p.getPatient_id()!=0) {
    p.setPatientName(patient.getPatientName());
    p.setGender(patient.getGender());
    p.setAge(patient.getAge());
    p.setBloodGroup(patient.getBloodGroup());
    p.setPhoneNumber(patient.getPhoneNumber());
    p.setIssue(patient.getIssue());
    p.setStatus(patient.getStatus());
  }
return new ResponseEntity<Patient>(patientRepository.save(p),HttpStatus.OK);
}
}
