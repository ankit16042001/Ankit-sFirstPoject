package com.example.Hospital_Reception_System.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.Hospital_Reception_System.DTO.EmployeeDTO_Receptionist;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.Service.EmployeeService;
import com.example.Hospital_Reception_System.response.LoginResponse_Receptionist;
@RestController
@CrossOrigin
@RequestMapping("api/v1/employee")
public class EmployeeController_Receptionist {
	@Autowired
    private EmployeeService employeeService;
    @PostMapping(path = "/save")
    public String saveEmployee(@RequestBody EmployeeDTO_Receptionist employeeDTO_Receptionist)
    {
        String id = employeeService.addEmployee(employeeDTO_Receptionist);
        return id;
    }
    @PostMapping(path = "/login")
    public ResponseEntity<?> loginEmployee(@RequestBody LoginDTO loginDTO)
    {
    	LoginResponse_Receptionist loginResponse = employeeService.loginResponse_Receptionist(loginDTO);
        return ResponseEntity.ok(loginResponse);
    }
}
