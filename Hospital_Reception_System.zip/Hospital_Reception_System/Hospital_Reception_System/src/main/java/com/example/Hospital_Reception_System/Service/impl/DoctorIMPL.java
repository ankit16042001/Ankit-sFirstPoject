package com.example.Hospital_Reception_System.Service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Hospital_Reception_System.DTO.DoctorDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.Entity.Doctor;
import com.example.Hospital_Reception_System.Repo.DoctorRepo;
import com.example.Hospital_Reception_System.Service.DoctorService;
import com.example.Hospital_Reception_System.response.LoginResponse_Doctor;

@Service
public class DoctorIMPL implements DoctorService{
    @Autowired
    private DoctorRepo doctorRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;
	@Override
	public String addDoctor(DoctorDTO doctorDTO) {
		Doctor doctor=new Doctor(
			doctorDTO.getDoctor_id(),
			doctorDTO.getName(),
			this.passwordEncoder.encode(doctorDTO.getPassword()),
			doctorDTO.getAge(),
			doctorDTO.getGender(),
			doctorDTO.getSpecialization(),
			doctorDTO.getExperience(),
			doctorDTO.getLanguage(),
			doctorDTO.getMobile_No(),
			doctorDTO.getEmail(),
			doctorDTO.getSchedule()
		);
		doctorRepo.save(doctor);
		return doctor.getName();
	}
	DoctorDTO doctorDTO;
	@Override
	public LoginResponse_Doctor loginResponse_Doctor(LoginDTO loginDTO) {
		String msg="";
		Doctor doctor1=doctorRepo.findByEmail(loginDTO.getEmail());
		if (doctor1 != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = doctor1.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<Doctor> doctor = doctorRepo.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (doctor.isPresent()) {
                    return new LoginResponse_Doctor("Login Success", true, loginDTO.getEmail());
                } else {
                    return new LoginResponse_Doctor("Login Failed", false, loginDTO.getEmail());
                }
            } else {
                return new LoginResponse_Doctor("password Not Match", false, loginDTO.getEmail());
            }
        }else {
            return new LoginResponse_Doctor("Email not exits", false, loginDTO.getEmail());
        }
	}
}
