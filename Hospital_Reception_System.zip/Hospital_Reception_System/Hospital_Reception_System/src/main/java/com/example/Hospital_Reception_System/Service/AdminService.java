package com.example.Hospital_Reception_System.Service;

import com.example.Hospital_Reception_System.DTO.AdminDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.response.LoginResponse_Admin;

public interface AdminService {
	String addAdmin(AdminDTO adminDTO);
    LoginResponse_Admin loginResponse_Admin(LoginDTO loginDTO);
}
