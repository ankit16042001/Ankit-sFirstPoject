package com.example.Hospital_Reception_System.Service;

import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.DTO.UserDTO;
import com.example.Hospital_Reception_System.response.LoginResponse_User;

public interface UserService {
    String addUser(UserDTO userDTO);
    LoginResponse_User loginResponse_User(LoginDTO loginDTO);
}
