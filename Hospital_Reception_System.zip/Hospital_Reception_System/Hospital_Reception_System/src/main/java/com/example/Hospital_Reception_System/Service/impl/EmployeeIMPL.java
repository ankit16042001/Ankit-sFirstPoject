package com.example.Hospital_Reception_System.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Hospital_Reception_System.DTO.EmployeeDTO_Receptionist;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.Entity.Employee_Receptionist;
import com.example.Hospital_Reception_System.Repo.EmployeeRepo_Receptionist;
import com.example.Hospital_Reception_System.Service.EmployeeService;
import com.example.Hospital_Reception_System.response.LoginResponse_Receptionist;

import jakarta.annotation.Resource;
import java.util.Optional;

@Service
public class EmployeeIMPL implements EmployeeService {
    @Autowired
    private EmployeeRepo_Receptionist employeeRepo_Receptionist;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Override
    public String addEmployee(EmployeeDTO_Receptionist employeeDTO_Receptionist) {
        Employee_Receptionist employee = new Employee_Receptionist(
                employeeDTO_Receptionist.getEmployeeid(),
                employeeDTO_Receptionist.getEmployeename(),
                employeeDTO_Receptionist.getEmail(),
               this.passwordEncoder.encode(employeeDTO_Receptionist.getPassword())
        );
        employeeRepo_Receptionist.save(employee);
        return employee.getEmployeename();
    }
    EmployeeDTO_Receptionist employeeDTO_Receptionist;
    @Override
    public LoginResponse_Receptionist  loginResponse_Receptionist(LoginDTO loginDTO) {
        String msg = "";
        Employee_Receptionist employee1_Receptionist = employeeRepo_Receptionist.findByEmail(loginDTO.getEmail());
        if (employee1_Receptionist != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = employee1_Receptionist.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<Employee_Receptionist> employee_Receptionist = employeeRepo_Receptionist.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (employee_Receptionist.isPresent()) {
                    return new LoginResponse_Receptionist("Login Success", true);
                } else {
                    return new LoginResponse_Receptionist("Login Failed", false);
                }
            } else {
                return new LoginResponse_Receptionist("password Not Match", false);
            }
        }else {
            return new LoginResponse_Receptionist("Email not exits", false);
        }
    }

}
