package com.example.Hospital_Reception_System.Entity;

import jakarta.persistence.*;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "doctorschedule")
public class DoctorSchedule {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long appointment_No;
	 private String patientName;
	 private String doctorName;
	 private String timing;
	 private String issue;
	 private String status;
	public DoctorSchedule() {
	}
	public DoctorSchedule(long appointment_No, String patientName, String doctorName, String timing, String issue,
			String status) {
		super();
		this.appointment_No = appointment_No;
		this.patientName = patientName;
		this.doctorName = doctorName;
		this.timing = timing;
		this.issue = issue;
		this.status = status;
	}
	public long getAppointment_No() {
		return appointment_No;
	}
	public String getPatientName() {
		return patientName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public String getTiming() {
		return timing;
	}
	public String getIssue() {
		return issue;
	}
	public String getStatus() {
		return status;
	}
	public void setAppoinment_No(long appointment_No) {
		this.appointment_No = appointment_No;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public void setTiming(String timing) {
		this.timing = timing;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
