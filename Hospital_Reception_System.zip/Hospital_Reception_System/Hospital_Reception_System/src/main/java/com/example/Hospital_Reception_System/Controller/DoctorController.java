package com.example.Hospital_Reception_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.DTO.DoctorDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.Entity.Doctor;
import com.example.Hospital_Reception_System.Repo.DoctorRepo;
import com.example.Hospital_Reception_System.Service.DoctorService;
import com.example.Hospital_Reception_System.response.LoginResponse_Doctor;

@RestController
@CrossOrigin
@RequestMapping("api/v1/doctor")
public class DoctorController {
	@Autowired
	private DoctorService doctorService;
	
    @GetMapping("/search_doctor")
    public List<Doctor> searchItems(@RequestParam String name) {
        return doctorRepository.findBynameContaining(name);
    }
    
    @PostMapping(path = "/save")
    public String saveDoctor(@RequestBody DoctorDTO doctorDTO) {
    	String id=doctorService.addDoctor(doctorDTO);
    	return id;
    }
    @PostMapping(path = "/doctor_login")
    public ResponseEntity<?> loginEmployee(@RequestBody LoginDTO loginDTO){
    	LoginResponse_Doctor loginResponse_Doctor=doctorService.loginResponse_Doctor(loginDTO);
    	return ResponseEntity.ok(loginResponse_Doctor);
    }
	@Autowired
	 private DoctorRepo doctorRepository;
	 @GetMapping("/doctors")
	 public Page<Doctor> getAllDoctors(Pageable pageable) {
	  return doctorRepository.findAll(pageable);
	 }
	 
	        //For Deleteing a record
	 @DeleteMapping("/doctors/{doctor_id}")
	 public ResponseEntity<Doctor> deleteDoctor(@PathVariable("doctor_id") long doctor_id){
	  try {
	   System.out.println("inside");
	   doctorRepository.deleteById(doctor_id);
	  return new ResponseEntity<Doctor>(HttpStatus.OK);
	  }
	  catch (Exception e) {
	   // TODO: handle exception
	   return new ResponseEntity<Doctor>(HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	 }
	 
	 
////Add a Patient
//@PostMapping("/doctors")
//public ResponseEntity<Doctor> addDoctors(@RequestBody Doctor doctor) {
//return new ResponseEntity<Doctor>(doctorRepository.save(doctor), HttpStatus.OK);
//}


//Get Books By Id
@GetMapping("/doctor/doctors/{doctor_id}")
public ResponseEntity<Doctor> getDoctorById(@PathVariable("doctor_id") long doctor_id) {
System.out.println("here");
return new ResponseEntity<Doctor>(doctorRepository.findById(doctor_id).get(),HttpStatus.OK);

}
@PutMapping("/doctor/doctors/{doctor_id}")
public ResponseEntity<Doctor> updateDoctor(@PathVariable("doctor_id") long doctor_id, @RequestBody Doctor doctor){
	Doctor d = doctorRepository.findById(doctor_id).get();
 if(d.getDoctor_id()!=0) {
	d.setName(doctor.getName());
	d.setAge(doctor.getAge());
   d.setGender(doctor.getGender());
   d.setSpecialization(doctor.getSpecialization());
   d.setExperience(doctor.getExperience());
   d.setLanguage(doctor.getLanguage());
   d.setMobile_No(doctor.getMobile_No());
   d.setEmail(doctor.getEmail());
   d.setSchedule(doctor.getSchedule());
 }
return new ResponseEntity<Doctor>(doctorRepository.save(d),HttpStatus.OK);
}
}
