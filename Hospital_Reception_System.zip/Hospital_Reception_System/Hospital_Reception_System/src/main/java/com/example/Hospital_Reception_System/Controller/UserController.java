package com.example.Hospital_Reception_System.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.DTO.UserDTO;
import com.example.Hospital_Reception_System.Service.UserService;
import com.example.Hospital_Reception_System.response.LoginResponse_User;


@RestController
@CrossOrigin
@RequestMapping("api/v1/user")
public class UserController {
	@Autowired
	private UserService userService;
    @PostMapping(path = "/save")
    public String saveUser(@RequestBody UserDTO userDTO) {
    	String id=userService.addUser(userDTO);
    	return id;
    }
    @PostMapping(path = "/user_login")
    public ResponseEntity<?> loginEmployee(@RequestBody LoginDTO loginDTO){
    	LoginResponse_User loginResponse_User=userService.loginResponse_User(loginDTO);
    	return ResponseEntity.ok(loginResponse_User);
    }


}
