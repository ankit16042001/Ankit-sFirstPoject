package com.example.Hospital_Reception_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.Entity.DoctorSchedule;
import com.example.Hospital_Reception_System.Repo.DoctorScheduleRepository;

@RestController
@CrossOrigin
@RequestMapping("api/v1")
public class DoctorScheduleController {
	@Autowired
	 private DoctorScheduleRepository doctorScheduleRepository;
	
    @GetMapping("/search_doctorschedule_patientName")
    public List<DoctorSchedule> searchItems(@RequestParam String patientName) {
        return doctorScheduleRepository.findBypatientNameContaining(patientName);
    }
    @GetMapping("/search_doctorschedule_doctorName")
    public List<DoctorSchedule> searchItems1(@RequestParam String doctorName) {
        return doctorScheduleRepository.findBydoctorNameContaining(doctorName);
    }
    
	 @GetMapping("/doctorSchedules")
	 public Page<DoctorSchedule> getAllDoctorSchedule(Pageable pageable) {
	  return doctorScheduleRepository.findAll(pageable);
	 }
	 
	        //For Deleteing a record
	 @DeleteMapping("/doctorSchedules/{appointment_No}")
	 public ResponseEntity<DoctorSchedule> deleteDoctorSchedule(@PathVariable("appointment_No") long appointment_No){
	  try {
	   System.out.println("inside");
	   doctorScheduleRepository.deleteById(appointment_No);
	  return new ResponseEntity<DoctorSchedule>(HttpStatus.OK);
	  }
	  catch (Exception e) {
	   // TODO: handle exception
	   return new ResponseEntity<DoctorSchedule>(HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	 }
	 
	 
//Add a Patient
@PostMapping("/doctorSchedules")
public ResponseEntity<DoctorSchedule> addDoctorSchedule(@RequestBody DoctorSchedule doctorSchedule) {
return new ResponseEntity<DoctorSchedule>(doctorScheduleRepository.save(doctorSchedule), HttpStatus.OK);
}


//Get Books By Id
@GetMapping("/doctorSchedule/doctorSchedules/{appointment_No}")
public ResponseEntity<DoctorSchedule> getDoctorScheduleById(@PathVariable("appointment_No") long appointment_No) {
System.out.println("here");
return new ResponseEntity<DoctorSchedule>(doctorScheduleRepository.findById(appointment_No).get(),HttpStatus.OK);

}
@PutMapping("/doctorSchedule/doctorSchedules/{appointment_No}")
public ResponseEntity<DoctorSchedule> updateDoctorSchedule(@PathVariable("appointment_No") long appointment_No, @RequestBody DoctorSchedule doctorSchedule){
	DoctorSchedule ds = doctorScheduleRepository.findById(appointment_No).get();
  if(ds.getAppointment_No()!=0) {
    ds.setPatientName(doctorSchedule.getPatientName());
    ds.setDoctorName(doctorSchedule.getDoctorName());
    ds.setTiming(doctorSchedule.getTiming());
    ds.setIssue(doctorSchedule.getIssue());
    ds.setStatus(doctorSchedule.getStatus());
  }
return new ResponseEntity<DoctorSchedule>(doctorScheduleRepository.save(ds),HttpStatus.OK);
}
}
