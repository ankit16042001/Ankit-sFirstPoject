package com.example.Hospital_Reception_System.Service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Hospital_Reception_System.DTO.AdminDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.DTO.UserDTO;
import com.example.Hospital_Reception_System.Entity.Admin;
import com.example.Hospital_Reception_System.Entity.User;
import com.example.Hospital_Reception_System.Repo.AdminRepo;
import com.example.Hospital_Reception_System.Service.AdminService;
import com.example.Hospital_Reception_System.response.LoginResponse_Admin;
import com.example.Hospital_Reception_System.response.LoginResponse_User;

@Service
public class AdminIMPL implements AdminService{
	@Autowired
	private AdminRepo adminRepo;
	@Autowired
	private PasswordEncoder passwordEncoder;
	public String addAdmin(AdminDTO adminDTO) {
		Admin admin=new Admin(
			adminDTO.getAdminid(),
			adminDTO.getAdminname(),
			adminDTO.getEmail(),
			this.passwordEncoder.encode(adminDTO.getPassword())
		);
		adminRepo.save(admin);
		return admin.getAdminname();
	}
	AdminDTO adminDTO;
	@Override
	public LoginResponse_Admin loginResponse_Admin(LoginDTO loginDTO) {
		String msg="";
		Admin admin=adminRepo.findByEmail(loginDTO.getEmail());
		if (admin != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = admin.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<Admin> user = adminRepo.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (user.isPresent()) {
                    return new LoginResponse_Admin("Login Success", true);
                } else {
                    return new LoginResponse_Admin("Login Failed", false);
                }
            } else {
                return new LoginResponse_Admin("password Not Match", false);
            }
        }else {
            return new LoginResponse_Admin("Email not exits", false);
        }
	}

}
