package com.example.Hospital_Reception_System.Service;

import com.example.Hospital_Reception_System.DTO.EmployeeDTO_Receptionist;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.response.LoginResponse_Receptionist;

public interface EmployeeService {
    String addEmployee(EmployeeDTO_Receptionist employeeDTO);
    LoginResponse_Receptionist loginResponse_Receptionist(LoginDTO loginDTO);

}
