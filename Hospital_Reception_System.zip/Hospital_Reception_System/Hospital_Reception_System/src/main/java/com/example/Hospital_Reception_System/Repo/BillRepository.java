package com.example.Hospital_Reception_System.Repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Hospital_Reception_System.Entity.Bill;

public interface BillRepository extends JpaRepository<Bill, Long> {
	List<Bill> findBypatientNameContaining(String patientName);

}
