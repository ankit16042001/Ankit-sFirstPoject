package com.example.Hospital_Reception_System.Service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.DTO.UserDTO;
import com.example.Hospital_Reception_System.Entity.User;
import com.example.Hospital_Reception_System.Repo.UserRepo;
import com.example.Hospital_Reception_System.Service.UserService;
import com.example.Hospital_Reception_System.response.LoginResponse_User;

@Service
public class UserIMPL implements UserService{
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;
	@Override
	public String addUser(UserDTO userDTO) {
		User user=new User(
			userDTO.getUserid(),
			userDTO.getUsername(),
			userDTO.getEmail(),
			this.passwordEncoder.encode(userDTO.getPassword())
		);
		userRepo.save(user);
		return user.getUsername();
	}
	UserDTO userDTO;
	@Override
	public LoginResponse_User loginResponse_User(LoginDTO loginDTO) {
		String msg="";
		User user1=userRepo.findByEmail(loginDTO.getEmail());
		if (user1 != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = user1.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<User> user = userRepo.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (user.isPresent()) {
                    return new LoginResponse_User("Login Success", true);
                } else {
                    return new LoginResponse_User("Login Failed", false);
                }
            } else {
                return new LoginResponse_User("password Not Match", false);
            }
        }else {
            return new LoginResponse_User("Email not exits", false);
        }
	}
}
