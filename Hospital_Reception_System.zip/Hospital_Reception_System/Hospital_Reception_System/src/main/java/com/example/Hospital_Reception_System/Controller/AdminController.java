package com.example.Hospital_Reception_System.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hospital_Reception_System.DTO.AdminDTO;
import com.example.Hospital_Reception_System.DTO.LoginDTO;
import com.example.Hospital_Reception_System.Service.AdminService;
import com.example.Hospital_Reception_System.response.LoginResponse_Admin;

@RestController
@CrossOrigin
@RequestMapping("api/v1/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
    @PostMapping(path = "/save")
    public String saveAdmin(@RequestBody AdminDTO adminDTO) {
    	String id=adminService.addAdmin(adminDTO);
    	return id;
    }
    @PostMapping(path = "/admin_login")
    public ResponseEntity<?> loginAdmin(@RequestBody LoginDTO loginDTO){
    	LoginResponse_Admin loginResponse_Admin=adminService.loginResponse_Admin(loginDTO);
    	return ResponseEntity.ok(loginResponse_Admin);
    }


}
