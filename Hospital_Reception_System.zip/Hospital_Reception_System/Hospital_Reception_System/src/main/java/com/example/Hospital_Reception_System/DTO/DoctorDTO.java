package com.example.Hospital_Reception_System.DTO;

public class DoctorDTO {
	private long doctor_id;
	 private String name;
	 private String password;
	 private long age;
	 private String gender;
	 private String specialization;
	 private String experience;
	 private String language;
	 private String mobile_No;
	 private String email;
	 private String schedule;
	public DoctorDTO() {
		}
	public DoctorDTO(long doctor_id, String name, String password, long age, String gender, String specialization, String experience, String language,
			String mobile_No, String email, String schedule) {
		this.doctor_id = doctor_id;
		this.name = name;
		this.password = password;
		this.age = age;
		this.gender = gender;
		this.specialization = specialization;
		this.experience = experience;
		this.language = language;
		this.mobile_No = mobile_No;
		this.email = email;
		this.schedule = schedule;
		}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getDoctor_id() {
		return doctor_id;
	}
	public long getAge() {
		return age;
	}
	public String getGender() {
		return gender;
	}
	public String getSpecialization() {
		return specialization;
	}
	public String getExperience() {
		return experience;
	}
	public String getLanguage() {
		return language;
	}
	public String getMobile_No() {
		return mobile_No;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setDoctor_id(long doctor_id) {
		this.doctor_id = doctor_id;
	}
	public void setAge(long age) {
		this.age = age;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public void setMobile_No(String mobile_No) {
		this.mobile_No = mobile_No;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}	
}
