package com.example.Hospital_Reception_System.Repo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.example.Hospital_Reception_System.Entity.Employee_Receptionist;

import java.util.Optional;
@EnableJpaRepositories
@Repository
public interface EmployeeRepo_Receptionist  extends JpaRepository<Employee_Receptionist,Integer>{
    Optional<Employee_Receptionist> findOneByEmailAndPassword(String email, String password);
    Employee_Receptionist findByEmail(String email);
}
