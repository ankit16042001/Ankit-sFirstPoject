package com.example.Hospital_Reception_System.Entity;

import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "bill")
public class Bill {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long bill_No;
	 private String patientName;
	 private String doctor_Name;
	 private long amount;
	 private String insurance;
	 private String report_Status;
	 
	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bill(long bill_No, String patientName, String doctor_Name, long amount, String insurance,
			String report_Status) {
		super();
		this.bill_No = bill_No;
		this.patientName = patientName;
		this.doctor_Name = doctor_Name;
		this.amount = amount;
		this.insurance = insurance;
		this.report_Status = report_Status;
	}

	public long getBill_No() {
		return bill_No;
	}

	public String getPatientName() {
		return patientName;
	}

	public String getDoctor_Name() {
		return doctor_Name;
	}

	public long getAmount() {
		return amount;
	}

	public String getInsurance() {
		return insurance;
	}

	public String getReport_Status() {
		return report_Status;
	}

	public void setBill_No(long bill_No) {
		this.bill_No = bill_No;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public void setDoctor_Name(String doctor_Name) {
		this.doctor_Name = doctor_Name;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public void setReport_Status(String report_Status) {
		this.report_Status = report_Status;
	}
	
}
