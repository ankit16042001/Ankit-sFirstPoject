package com.example.Hospital_Reception_System.Repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.example.Hospital_Reception_System.Entity.DoctorSchedule;

@EnableJpaRepositories
@Repository
public interface DoctorScheduleRepository extends JpaRepository<DoctorSchedule, Long>{
	List<DoctorSchedule> findBypatientNameContaining(String patientName);
	List<DoctorSchedule> findBydoctorNameContaining(String doctorName);
}
